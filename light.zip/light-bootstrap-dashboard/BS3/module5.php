<!doctype html>
<html lang="en">
<head>
    <?php include('header.php');?> 
</head>
<body>

<div class="wrapper">
    <!-- <div class="sidebar" data-color="purple" data-image="assets/img/sidebar-5.jpg"> !-->
      <?php include('sidebar.php');?> 
    
<div class="main-panel">
    <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">

                            <div class="header">
                                <h4 class="title">Module 1 comliance</h4>
                                <p class="category">Last Campaign Performance</p>
                            </div>
                            
<!--                             <div class="content">
                                <div id="chartPreferences" class="ct-chart ct-perfect-fourth"></div>

                                <div class="footer">
                                    <div class="legend">
                                        <i class="fa fa-circle text-info"></i> Open
                                        <i class="fa fa-circle text-danger"></i> Bounce
                                        <i class="fa fa-circle text-warning"></i> Unsubscribe
                                    </div>
                                    <hr>
                                    <div class="stats">
                                        <i class="fa fa-clock-o"></i> Campaign sent 2 days ago
                                    </div>
                                </div>
                            </div>
 -->                        </div>
                    </div>
                      <?php
                       $random_code_post = filter_input(INPUT_GET, 'user_input', FILTER_VALIDATE_INT);
                       $command = 'python3 /var/www/html/py1.py' . $random_code_post;
                       $python3 = shell_exec($command);
                       echo $python3;
                       ?>

                    <!-- <div class="col-md-6">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">module_2 compliance</h4>
                                <p class="category">24 Hours performance</p>
                            </div> -->
                            <!-- <div class="content">
                                <div id="chartHours" class="ct-chart"></div>
                                <div class="footer">
                                    <div class="legend">
                                        <i class="fa fa-circle text-info"></i> Open
                                        <i class="fa fa-circle text-danger"></i> Click
                                        <i class="fa fa-circle text-warning"></i> Click Second Time
                                    </div>
                                    <hr>
                                    <div class="stats">
                                        <i class="fa fa-history"></i> Updated 3 minutes ago
                                    </div>
                                </div>
                            </div> -->
                        </div>
                    </div>
                </div>
        </div>
    </div>
</div>








    <!--

        Tip 1: you can change the color of the sidebar using: data-color="blue | azure | green | orange | red | purple"
        Tip 2: you can also add an image using data-image tag
      
    -->
     <!--   <?php include('mainpanel.php');?> -->

        <!-- <div class="sidebar-wrapper">
            <div class="logo">
                <a href="http://www.creative-tim.com" class="simple-text">
                    Creative Tim
                </a>
            </div>

            <ul class="nav">
                <li class="active">
                    <a href="dashboard.html">
                        <i class="pe-7s-graph"></i>
                        <p>Dashboard</p>
                    </a>
                </li>
                <li>
                    <a href="user.html">
                        <i class="pe-7s-user"></i>
                        <p>User Profile</p>
                    </a>
                </li>
                <li>
                    <a href="table.html">
                        <i class="pe-7s-note2"></i>
                        <p>Table List</p>
                    </a>
                </li>
                <li>
                    <a href="typography.html">
                        <i class="pe-7s-news-paper"></i>
                        <p>Typography</p>
                    </a>
                </li>
                <li>
                    <a href="icons.html">
                        <i class="pe-7s-science"></i>
                        <p>Icons</p>
                    </a>
                </li>
                <li>
                    <a href="maps.html">
                        <i class="pe-7s-map-marker"></i>
                        <p>Maps</p>
                    </a>
                </li>
                <li>
                    <a href="notifications.html">
                        <i class="pe-7s-bell"></i>
                        <p>Notifications</p>
                    </a>
                </li>
                <li class="active-pro">
                    <a href="upgrade.html">
                        <i class="pe-7s-rocket"></i>
                        <p>Upgrade to PRO</p>
                    </a>
                </li>
            </ul>
        </div>
    </div>  -->

   
</div>
<?php include('script.php');?>

</body>

    <!--   Core JS Files   -->
    

</html>
