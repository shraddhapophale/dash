<!doctype html>
<html lang="en">
<head>
	 <?php include('header.php');?>
</head>
<body>

<div class="wrapper">
     <?php include('sidebar.php');?>
    <div class="main-panel">
        <?php include('navbar.php');?>

        

<!-- footer sction !-->
        <?php include('footer.php');?>
    </div>
</div>


</body>
 <?php include('jsscript.php');?>
    <!--   Core JS Files   -->
    
</html>
